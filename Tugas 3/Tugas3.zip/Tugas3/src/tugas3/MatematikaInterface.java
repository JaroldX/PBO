package tugas3;

interface MatematikaInterface {
    int pertambahan(int a, int b);
    int pengurangan(int a, int b);
    int perkalian(int a, int b);
    double pembagian(int a, int b);
}
