package tugas3;

class KonversiSuhu {
    public double celciusToFahrenheit(double celcius) {
        return (celcius * 9/5) + 32;
    }

    public double celciusToReamur(double celcius) {
        return celcius * 4/5;
    }
}

class KonversiSuhu2 extends KonversiSuhu {
    public double fahrenheitToReamur(double fahrenheit) {
        return (fahrenheit - 32) * 4/9;
    }
}

class DemoKonversiSuhu {
    public static void main(String[] args) {
        KonversiSuhu konversiSuhu = new KonversiSuhu();
        KonversiSuhu2 konversiSuhu2 = new KonversiSuhu2();

        double celcius = 25;
        double fahrenheit = 77;

        System.out.println(celcius + "°C = " + konversiSuhu.celciusToFahrenheit(celcius) + "°F");
        System.out.println(celcius + "°C = " + konversiSuhu.celciusToReamur(celcius) + "°R");
        System.out.println(fahrenheit + "°F = " + konversiSuhu2.fahrenheitToReamur(fahrenheit) + "°R");
    }
}