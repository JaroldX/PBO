package tugas3;

class Matematika2 extends Matematika {
    public int modulus(int a, int b) {
        if (b != 0) {
            return a % b;
        } else {
            System.out.println("Error: Pembagi tidak boleh nol.");
            return 0;
        }
    }
}

class MatematikaInheritance {
    public static void main(String[] args) {
        Matematika matematika = new Matematika();
        Matematika2 matematika2 = new Matematika2();

        int a = 10, b = 3;

        System.out.println("Pertambahan: " + matematika.pertambahan(a, b));
        System.out.println("Pengurangan: " + matematika.pengurangan(a, b));
        System.out.println("Perkalian: " + matematika.perkalian(a, b));
        System.out.println("Pembagian: " + matematika.pembagian(a, b));
        System.out.println("Modulus: " + matematika2.modulus(a, b));
    }
}